const hiddenCate= document.querySelector("#hiddenCate");
const menu = document.querySelector("#menu");

function openHidden(){
  hiddenCate.style.display = "inline-block";
  menu.style.display = "none";
}

function closeHidden(){
  hiddenCate.style.display = "none";
  menu.style.display = "inline-block";
}
