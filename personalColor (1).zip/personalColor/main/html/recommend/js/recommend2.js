const type1 = document.querySelector("#type1");
const type2 = document.querySelector("#type2");
const type3 = document.querySelector("#type3");

function gotype1(){
  type1.style.display = "block";
  type2.style.display = "none";
  type3.style.display = "none";
}

function gotype2(){
  type1.style.display = "none";
  type2.style.display = "block";
  type3.style.display = "none";
}

function gotype3(){
  type1.style.display = "none";
  type2.style.display = "none";
  type3.style.display = "block";
}
