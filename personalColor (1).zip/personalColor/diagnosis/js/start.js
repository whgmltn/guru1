const main = document.querySelector("#main");
const qna = document.querySelector("#qna");
const result = document.querySelector("#result");
const endPoint = 7;
const select = [0, 0, 0, 0];

// 가장 많은 선택을 한 type을 계산한다.
function calResult(){
  var result = select.indexOf(Math.max(...select));
  return result;
}

// 자가진단 결과에 따라 화면이 나올 수 있도록 세팅한다.
function setResult(){
  // 결과 퍼스널 컬러 타입 결정
  let point = calResult();
  const resultName = document.querySelector('.resultname');
  resultName.innerHTML = infoList[point].name;

  // 결과 이미지 결정
  var resultImg = document.createElement('img');
  const imgDiv = document.querySelector('#resultImg');
  var imgURL = 'diagnosis/img/image' + point + '.jpg';
  resultImg.src = imgURL;
  resultImg.alt = point;
  resultImg.classList.add('img-fluid');
  imgDiv.appendChild(resultImg);

  // 결과에 맞는 설명이 나오도록 설정
  const resultDesc = document.querySelector('.resultDesc');
  resultDesc.innerHTML = infoList[point].desc;
}

// qna 창에서 result 창으로 넘어간다. 부드럽게 넘어가도록 시간 지연 애니메이션을 넣어준다.
function goResult(){
  qna.style.WebkitAnimation = "fadeOut 1s";
  qna.style.animation = "fadeOut 1s";
  setTimeout(() => {
    result.style.WebkitAnimation = "fadeIn 1s";
    result.style.animation = "fadeIn 1s";
    setTimeout(() => {
      qna.style.display = "none";
      result.style.display = "block";
    }, 450)})
    setResult();
}


// 질문에 대한 답변 부분이 바뀔 수 있도록 하고 선택한 답변의 타입의 select 값을 +1 해준다.
function addAnswer(answerText, qIdx, idx){
  var a = document.querySelector('.answerBox');
  var answer = document.createElement('button');
  answer.classList.add('answerList');
  answer.classList.add('my-0');
  answer.classList.add('py-3');
  answer.classList.add('mx-auto');

  a.appendChild(answer);
  a.classList.add('mx-5');
  answer.innerHTML = answerText;

  answer.addEventListener("click", function(){
    var children = document.querySelectorAll('.answerList');
    for(let i = 0; i < children.length; i++){
      children[i].disabled = true;
      children[i].style.display = 'none';
    }
    var target = qnaList[qIdx].a[idx].type;
    for(let j = 0; j < target.length; j++){
      select[target[j]] += 1;
    }

    goNext(++qIdx);
  }, false);

  if(qIdx == 0){
    ansImg0.style.display = "block";
    ansImg1.style.display = "none";
    ansImg2.style.display = "none";
    ansImg3.style.display = "none";
    ansImg4.style.display = "none";
    ansImg5.style.display = "none";
    ansImg6.style.display = "none";
  }

  if(qIdx == 1){
    ansImg0.style.display = "none";
    ansImg1.style.display = "block";
    ansImg2.style.display = "none";
    ansImg3.style.display = "none";
    ansImg4.style.display = "none";
    ansImg5.style.display = "none";
    ansImg6.style.display = "none";
  }

  if(qIdx == 2){
    ansImg0.style.display = "none";
    ansImg1.style.display = "none";
    ansImg2.style.display = "block";
    ansImg3.style.display = "none";
    ansImg4.style.display = "none";
    ansImg5.style.display = "none";
    ansImg6.style.display = "none";
  }

  if(qIdx == 3){
    ansImg0.style.display = "none";
    ansImg1.style.display = "none";
    ansImg2.style.display = "none";
    ansImg3.style.display = "block";
    ansImg4.style.display = "none";
    ansImg5.style.display = "none";
    ansImg6.style.display = "none";
  }

  if(qIdx == 4){
    ansImg0.style.display = "none";
    ansImg1.style.display = "none";
    ansImg2.style.display = "none";
    ansImg3.style.display = "none";
    ansImg4.style.display = "block";
    ansImg5.style.display = "none";
    ansImg6.style.display = "none";
  }

  if(qIdx == 5){
    ansImg0.style.display = "none";
    ansImg1.style.display = "none";
    ansImg2.style.display = "none";
    ansImg3.style.display = "none";
    ansImg4.style.display = "none";
    ansImg5.style.display = "block";
    ansImg6.style.display = "none";
  }

  if(qIdx == 6){
    ansImg0.style.display = "none";
    ansImg1.style.display = "none";
    ansImg2.style.display = "none";
    ansImg3.style.display = "none";
    ansImg4.style.display = "none";
    ansImg5.style.display = "none";
    ansImg6.style.display = "block";
  }

}

// 질문이 끝날 경우 goResult() 함수를 사용하여 결과 페이지로 넘어간다.
function goNext(qIdx){
  if(qIdx === endPoint){
    goResult();
    return;
  }

  var q = document.querySelector('.qBox');
  q.innerHTML = qnaList[qIdx].q;
  for(let i in qnaList[qIdx].a){
    addAnswer(qnaList[qIdx].a[i].answer, qIdx, i);
  }
  var status = document.querySelector('.statusBar');
  status.style.width = (100/(endPoint)) * (qIdx) + '%';
}

// 시작 페이지에서 qna 페이지로 넘어간다. 부드럽게 넘어가도록 시간 지연 애니메이션을 넣어준다.
function begin(){
  main.style.WebkitAnimation = "fadeOut 1s";
  main.style.animation = "fadeOut 1s";
  setTimeout(() => {
    qna.style.WebkitAnimation = "fadeIn 1s";
    qna.style.animation = "fadeIn 1s";
    setTimeout(() => {
      main.style.display = "none";
      qna.style.display = "block";
    }, 450)
    let qIdx = 0;
    goNext(qIdx);
  }, 450);
}
