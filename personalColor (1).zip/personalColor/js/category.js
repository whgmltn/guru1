const hiddenCate= document.querySelector("#hiddenCate");
const menu = document.querySelector("#menu");

// 삼선 버튼을 누를 시 login 관련 메뉴들이 나온다.
function openHidden(){
  hiddenCate.style.display = "inline-block";
  menu.style.display = "none";
}
// x 버튼을 누를 시 login 관련 메뉴들이 들어간다.
function closeHidden(){
  hiddenCate.style.display = "none";
  menu.style.display = "inline-block";
}
